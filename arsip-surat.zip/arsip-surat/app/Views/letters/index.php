<div class="card">
  <div class="card-body">
    <form class="row g-2 align-items-center mb-2" method="get" action="<?= site_url('arsip'); ?>">
      <div class="col-sm-6 col-md-4">
        <input type="text" class="form-control" name="q" value="<?= esc($q); ?>" placeholder="Cari judul surat...">
      </div>
      <div class="col-auto">
        <button class="btn btn-primary btn-sm">Cari</button>
        <a class="btn btn-outline-secondary btn-sm" href="<?= site_url('arsip'); ?>">Reset</a>
      </div>
      <div class="col-auto ms-auto">
        <a class="btn btn-success btn-sm" href="<?= site_url('arsip/tambah'); ?>">Arsipkan Surat..</a>
      </div>
    </form>

    <div class="table-responsive">
      <table class="table table-bordered table-sm align-middle">
        <thead>
          <tr>
            <th style="width:40px">#</th>
            <th>Nomor Surat</th>
            <th>Judul</th>
            <th>Kategori</th>
            <th>Waktu Pengarsipan</th>
            <th style="width:210px">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if(empty($rows)): ?>
            <tr><td colspan="6" class="text-center text-muted">Tidak ada data</td></tr>
          <?php else:
            $no = 1 + (int)($pager->getCurrentPage() - 1) * $pager->getPerPage();
            foreach($rows as $r): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= esc($r['number']); ?></td>
              <td><?= esc($r['title']); ?></td>
              <td><?= esc($r['category_name']); ?></td>
              <td><?= date('d/m/Y H:i', strtotime($r['created_at'])); ?></td>
              <td>
                <a class="btn btn-outline-primary btn-sm" href="<?= site_url('arsip/'.$r['id']); ?>">Lihat >></a>
                <a class="btn btn-primary btn-sm" href="<?= site_url('arsip/unduh/'.$r['id']); ?>">Unduh</a>
                <a class="btn btn-danger btn-sm" href="#" onclick="return confirmDelete('<?= site_url('arsip/hapus/'.$r['id']); ?>')">Hapus</a>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
    <?= $pager->links(); ?>
  </div>
</div>
