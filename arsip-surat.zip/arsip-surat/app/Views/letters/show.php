<div class="card">
  <div class="card-body">
    <div class="mb-2">
      <strong>Nomor:</strong> <?= esc($row->number); ?> |
      <strong>Judul:</strong> <?= esc($row->title); ?> |
      <strong>Kategori:</strong> <?= esc($row->category_name); ?>
    </div>
    <div class="border" style="height:70vh">
      <iframe src="<?= site_url('viewer?f='.urlencode($row->file_name)); ?>" style="width:100%;height:100%;border:0"></iframe>
      <!-- Fallback sederhana tanpa viewer khusus -->
      <!-- <embed src="<?= base_url('filepdf/'.$row->file_name); ?>" type="application/pdf" width="100%" height="100%"> -->
    </div>
    <div class="mt-3">
      <a class="btn btn-secondary" href="<?= site_url('arsip'); ?>">Kembali <<</a>
      <a class="btn btn-primary" href="<?= site_url('arsip/unduh/'.$row->id); ?>">Unduh</a>
    </div>
  </div>
</div>
