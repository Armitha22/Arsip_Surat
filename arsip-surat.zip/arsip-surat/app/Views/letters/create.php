<div class="card">
  <div class="card-body">
    <form method="post" action="<?= site_url('arsip/simpan'); ?>" enctype="multipart/form-data" class="row g-3">
      <?= csrf_field(); ?>
      <div class="col-md-4">
        <label class="form-label">Nomor Surat</label>
        <input type="text" name="number" value="<?= old('number'); ?>" class="form-control" required>
      </div>
      <div class="col-md-8">
        <label class="form-label">Judul</label>
        <input type="text" name="title" value="<?= old('title'); ?>" class="form-control" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Kategori</label>
        <select name="category_id" class="form-select" required>
          <option value="">-- Pilih --</option>
          <?php foreach($categories as $c): ?>
            <option value="<?= $c['id']; ?>" <?= set_select('category_id',$c['id']); ?>><?= esc($c['name']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Asal Surat (opsional)</label>
        <input type="text" name="origin" value="<?= old('origin'); ?>" class="form-control">
      </div>
      <div class="col-12">
        <label class="form-label">File PDF</label>
        <input type="file" name="file" accept="application/pdf" class="form-control" required>
        <div class="form-text">Hanya PDF, maks 5 MB.</div>
      </div>
      <div class="col-12">
        <a class="btn btn-secondary" href="<?= site_url('arsip'); ?>">Kembali</a>
        <button class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
