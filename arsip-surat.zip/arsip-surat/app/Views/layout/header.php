<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= esc($title ?? 'Arsip Surat'); ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body { background:#f8fafc; }
  .sidebar { width:220px; min-height:100vh; background:#fff; border-right:1px solid #eee; position:fixed; }
  .sidebar a { display:block; padding:.65rem 1rem; color:#333; text-decoration:none; border-radius:.5rem; margin:.2rem .5rem;}
  .sidebar a.active, .sidebar a:hover { background:#e9f2ff; color:#0d6efd;}
  .content { margin-left:230px; padding:1.2rem;}
  .table thead th { background:#f1f5f9; }
</style>
</head>
<body>
<div class="sidebar p-3">
  <h5 class="mb-3">Menu</h5>
  <a class="<?= ($menu??'')==='arsip'?'active':''; ?>" href="<?= site_url('arsip'); ?>">Arsip</a>
  <a class="<?= ($menu??'')==='kategori'?'active':''; ?>" href="<?= site_url('kategori'); ?>">Kategori Surat</a>
  <a class="<?= ($menu??'')==='about'?'active':''; ?>" href="<?= site_url('about'); ?>">About</a>
</div>
<div class="content">
  <h3 class="mb-1"><?= esc($title ?? ''); ?></h3>
  <p class="text-muted">Berikut adalah surat-surat yang telah terbit dan diarsipkan. Klik <em>Lihat</em> pada kolom aksi untuk melihat detail surat.</p>

  <?php if(session()->getFlashdata('msg')): ?>
    <div class="alert alert-success small"><?= session()->getFlashdata('msg'); ?></div>
  <?php endif; ?>
  <?php if(session()->getFlashdata('errors')): $errs = (array)session()->getFlashdata('errors'); ?>
    <div class="alert alert-danger small mb-3">
      <?php foreach($errs as $e): ?><div><?= esc($e); ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>
