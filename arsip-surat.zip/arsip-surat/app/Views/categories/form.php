<div class="card">
  <div class="card-body">
    <form method="post" action="<?= $action; ?>" class="row g-3">
      <?= csrf_field(); ?>
      <div class="col-md-6">
        <label class="form-label">Nama Kategori</label>
        <input type="text" name="name" value="<?= esc($row['name'] ?? ''); ?>" class="form-control" required>
      </div>
      <div class="col-12">
        <a class="btn btn-secondary" href="<?= site_url('kategori'); ?>">Kembali</a>
        <button class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
