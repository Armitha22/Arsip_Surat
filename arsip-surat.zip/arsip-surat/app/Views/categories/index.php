<div class="card">
  <div class="card-body">
    <div class="mb-2 text-end">
      <a class="btn btn-success btn-sm" href="<?= site_url('kategori/tambah'); ?>">Tambah</a>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered table-sm align-middle">
        <thead><tr>
          <th style="width:60px">ID</th>
          <th>Nama Kategori</th>
          <th style="width:180px">Aksi</th>
        </tr></thead>
        <tbody>
        <?php if(empty($rows)): ?>
          <tr><td colspan="3" class="text-center text-muted">Tidak ada data</td></tr>
        <?php else: foreach($rows as $r): ?>
          <tr>
            <td><?= $r['id']; ?></td>
            <td><?= esc($r['name']); ?></td>
            <td>
              <a class="btn btn-primary btn-sm" href="<?= site_url('kategori/edit/'.$r['id']); ?>">Edit</a>
              <a class="btn btn-danger btn-sm" href="#" onclick="return confirmDelete('<?= site_url('kategori/hapus/'.$r['id']); ?>')">Hapus</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
