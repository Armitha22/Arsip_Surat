<div class="card">
  <div class="card-body d-flex gap-3">
    <img src="<?= esc($me['foto']); ?>" class="rounded" width="120" height="120" alt="Foto">
    <div>
      <h5 class="mb-1">About</h5>
      <div>Nama: <strong><?= esc($me['nama']); ?></strong></div>
      <div>Profil: <strong><?= esc($me['profil']); ?></strong></div>
      <div>NIM: <strong><?= esc($me['nim']); ?></strong></div>
      <div>Tanggal pembuatan: <strong><?= esc($me['tanggal']); ?></strong></div>
    </div>
  </div>
</div>
